"use strict";
import App from './app.js';

const app = new App();
app.start();
